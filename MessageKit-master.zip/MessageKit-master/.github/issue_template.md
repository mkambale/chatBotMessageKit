## General Information

* MessageKit Version:

* iOS Version(s):

* Swift Version:

* Devices/Simulators:

* Reproducible in ChatExample? (Yes/No):



##  What happened?




## What did you expect to happen?






